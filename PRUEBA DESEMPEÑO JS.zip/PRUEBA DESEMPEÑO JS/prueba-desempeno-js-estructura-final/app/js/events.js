// CRUD DE EVENTOS PARA ADMIN

const user = JSON.parse(localStorage.getItem('user'));

// Solo admin puede estar aquí
if (!user || user.role !== "admin") {
  alert("Acceso denegado. Solo administradores.");
  window.location.href = "../dashboard.html";
}

// CREAR EVENTO
const eventForm = document.getElementById('eventForm');

if (eventForm) {
  eventForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const title = document.getElementById('title').value;
    const date = document.getElementById('date').value;
    const capacity = parseInt(document.getElementById('capacity').value);

    const newEvent = { title, date, capacity, registered: 0 };

    try {
      const res = await fetch('http://localhost:3002/events', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newEvent)
      });

      if (res.ok) {
        alert("Evento creado con éxito");
        window.location.href = "../dashboard.html";
      } else {
        alert("Error al crear el evento");
      }
    } catch (err) {
      console.error(err);
      alert("Error en la conexión");
    }
  });
}

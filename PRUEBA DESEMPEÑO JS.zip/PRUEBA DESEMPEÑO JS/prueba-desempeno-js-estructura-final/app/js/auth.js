// SCRIPT PARA LOGIN Y REGISTRO DE USUARIOS

const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');

// LOGIN DE USUARIO
if (loginForm) {
  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    try {
      const checkUser = await fetch(`http://localhost:3002/users?username=${username}`);
      const foundUsers = await checkUser.json();

      if (foundUsers.length === 0) {
        alert('Este usuario no está registrado. Por favor regístrate primero.');
        return;
      }

      const res = await fetch(`http://localhost:3002/users?username=${username}&password=${password}`);
      const users = await res.json();

      if (users.length > 0) {
        const user = users[0];
        localStorage.setItem('user', JSON.stringify(user));
        alert('Inicio de sesión exitoso');
        window.location.href = './dashboard.html';
      } else {
        alert('Contraseña incorrecta');
      }
    } catch (err) {
      console.error(err);
      alert('Error al iniciar sesión');
    }
  });
}

// REGISTRO DE USUARIO (solo visitantes)
if (registerForm) {
  registerForm.addEventListener('submit', async (e) => {
    e.preventDefault();

    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    try {
      const check = await fetch(`http://localhost:3002/users?username=${username}`);
      const existing = await check.json();

      if (existing.length > 0) {
        alert('Este usuario ya existe');
        return;
      }

      const newUser = {
        username,
        password,
        role: "visitor"  // los registrados siempre son visitantes
      };

      const res = await fetch('http://localhost:3002/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newUser)
      });

      if (res.ok) {
        alert('Registrado con éxito');
        window.location.href = './login.html';
      } else {
        alert('Error al registrar usuario');
      }
    } catch (err) {
      console.error(err);
      alert('Error al conectar con el servidor');
    }
  });
}

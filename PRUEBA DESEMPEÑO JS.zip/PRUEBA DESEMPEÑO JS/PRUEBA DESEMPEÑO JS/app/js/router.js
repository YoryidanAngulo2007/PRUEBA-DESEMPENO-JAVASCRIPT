// SCRIPT PARA MOSTRAR BIENVENIDA, VALIDAR SESIÓN Y GESTIONAR EVENTOS

// Obtiene el usuario desde el localStorage
const user = JSON.parse(localStorage.getItem('user'));

// ========== VALIDACIÓN DE SESIÓN ==========
if (!user) {
  // Si no hay usuario guardado, no tiene sesión activa
  alert('No tienes sesión activa');
  window.location.href = './login.html'; // Redirige al login
} else {
  // Si hay sesión activa, se personaliza el dashboard
  const welcome = document.getElementById('welcomeMessage');
  const roleText = document.getElementById('roleInfo');
  const logoutBtn = document.getElementById('logoutBtn');
  const nav = document.getElementById('mainNav');

  // Mensaje de bienvenida con el nombre de usuario
  if (welcome) welcome.textContent = `¡Hola, ${user.username}!`;

  // Muestra el rol actual del usuario
  if (roleText) roleText.textContent = `Tu rol es: ${user.role}`;

  // Muestra la navegación principal
  if (nav) nav.style.display = 'block';

  // Cierre de sesión (elimina el usuario del localStorage)
  logoutBtn.addEventListener('click', () => {
    localStorage.removeItem('user');
    window.location.href = './login.html'; // Redirige al login
  });

  // ========== VISIBILIDAD PARA ADMIN ==========
  if (user.role === "admin") {
    // Muestra panel exclusivo para administradores
    const adminPanel = document.getElementById("adminPanel");
    if (adminPanel) adminPanel.style.display = "block";

    // Muestra el enlace para crear eventos
    const adminCreateLink = document.getElementById("adminCreateLink");
    if (adminCreateLink) adminCreateLink.style.display = "inline";
  }

  // ========== CARGA Y VISUALIZACIÓN DE EVENTOS ==========
  fetch("http://localhost:3002/events")
    .then(res => res.json())
    .then(events => {
      const list = document.getElementById("eventsContainer");
      if (list) {
        list.innerHTML = ""; // Limpia cualquier contenido previo

        // Recorre todos los eventos y los muestra en lista
        events.forEach(event => {
          const li = document.createElement("li");
          li.innerHTML = `
            <strong>${event.title}</strong> - ${event.date} - Capacidad: ${event.capacity}
            ${user.role === 'admin' ? `
              <button onclick="editEvent(${event.id})">Editar</button>
              <button onclick="deleteEvent(${event.id})">Eliminar</button>
            ` : ''}
          `;
          list.appendChild(li); // Agrega el evento a la lista
        });
      }
    });
}

/* ========== FUNCIONES EXCLUSIVAS PARA ADMIN ========== */

// Elimina un evento por ID
function deleteEvent(id) {
  if (!confirm("¿Estás seguro de eliminar este evento?")) return;

  fetch(`http://localhost:3002/events/${id}`, {
    method: "DELETE"
  })
    .then(() => {
      alert("Evento eliminado");
      location.reload(); // Recarga la página para actualizar la lista
    })
    .catch(err => {
      alert("Error al eliminar evento");
      console.error(err);
    });
}

// Edita los datos de un evento
function editEvent(id) {
  fetch(`http://localhost:3002/events/${id}`)
    .then(res => res.json())
    .then(event => {
      // Pide al admin los nuevos datos del evento
      const title = prompt("Nuevo título del evento:", event.title);
      if (title === null) return;
      
      const date = prompt("Nueva fecha del evento (YYYY-MM-DD):", event.date);
      if (date === null) return;
      
      const capacity = prompt("Nueva capacidad del evento:", event.capacity);
      if (capacity === null) return;

      // Validación básica de datos
      if (!title || !date || isNaN(capacity)) {
        alert("Datos inválidos");
        return;
      }

      // Envía los cambios al backend
      return fetch(`http://localhost:3002/events/${id}`, {
        method: "PUT",
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title, date, capacity: parseInt(capacity) })
      });
    })
    .then(res => {
      if (res && res.ok) {
        alert("Evento actualizado");
        location.reload(); // Recarga para ver los cambios
      }
    })
    .catch(err => {
      alert("Error al actualizar evento");
      console.error(err);
    });
}

// Función para cambiar de sección (si hay múltiples secciones visibles)
function showSection(sectionId) {
  document.querySelectorAll('section').forEach(section => {
    section.classList.remove('active');
  });
  document.getElementById(sectionId).classList.add('active');
}
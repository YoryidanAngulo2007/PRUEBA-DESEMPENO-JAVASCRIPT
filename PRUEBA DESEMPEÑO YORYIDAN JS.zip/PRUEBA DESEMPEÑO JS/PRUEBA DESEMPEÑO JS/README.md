## ▶ Cómo ejecutar el proyecto

1. Instala dependencias en la carpeta raiz del proyecto:
```bash
npm install json-server --save-dev
```

2. Corre el servidor JSON:
```bash
npx json-server --watch db.json --port 3002
```

3. Abre `login.html` con Live Server (en VSCode).

## 🔐 Usuario por defecto
- Usuario: `admin`
- Contraseña: `admin123`
- Rol: `admin`

// CRUD DE EVENTOS PARA ADMINISTRADOR

// Se obtiene el usuario desde el localStorage
const user = JSON.parse(localStorage.getItem('user'));

// Verificación de acceso: solo los administradores pueden estar aquí
if (!user || user.role !== "admin") {
  alert("Acceso denegado. Solo administradores.");
  window.location.href = "../dashboard.html"; // Redirige si no es admin
}

// ========== CREACIÓN DE EVENTOS ========== //

// Se obtiene el formulario de eventos desde el DOM
const eventForm = document.getElementById('eventForm');

if (eventForm) {
  // Se escucha el envío del formulario
  eventForm.addEventListener('submit', async (e) => {
    e.preventDefault(); // Evita que se recargue la página

    // Se capturan los valores ingresados por el admin
    const title = document.getElementById('title').value;
    const date = document.getElementById('date').value;
    const capacity = parseInt(document.getElementById('capacity').value); // Se asegura que sea número

    // Se construye el objeto del nuevo evento
    const newEvent = {
      title,
      date,
      capacity,
      registered: 0 // Inicialmente no hay inscritos
    };

    try {
      // Se envía el evento al backend con método POST
      const res = await fetch('http://localhost:3002/events', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newEvent) // Se convierte a JSON el objeto
      });

      // Si el servidor responde bien, se confirma y se redirige
      if (res.ok) {
        alert("Evento creado con éxito");
        window.location.href = "../dashboard.html"; // Regresa al panel
      } else {
        alert("Error al crear el evento"); // Si algo falla con la respuesta
      }
    } catch (err) {
      // Si hay error de conexión o algo sale mal en la petición
      console.error(err);
      alert("Error en la conexión");
    }
  });
}
// SCRIPT PARA LOGIN Y REGISTRO DE USUARIOS

// Captura los formularios de login y registro desde el DOM
const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');

/* ========== BLOQUE DE INICIO DE SESIÓN ========== */
if (loginForm) {
  // Escucha el evento de envío del formulario de login
  loginForm.addEventListener('submit', async (e) => {
    e.preventDefault(); // Evita que se recargue la página al enviar el formulario

    // Captura el nombre de usuario y contraseña ingresados
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    try {
      // Verifica si el usuario existe en la base de datos
      const checkUser = await fetch(`http://localhost:3002/users?username=${username}`);
      const foundUsers = await checkUser.json();

      // Si no existe, muestra mensaje y detiene el proceso
      if (foundUsers.length === 0) {
        alert('Este usuario no está registrado. Por favor regístrate primero.');
        return;
      }

      // Busca si el usuario existe con la contraseña correcta
      const res = await fetch(`http://localhost:3002/users?username=${username}&password=${password}`);
      const users = await res.json();

      // Si hay coincidencia, guarda al usuario en el localStorage e inicia sesión
      if (users.length > 0) {
        const user = users[0]; // Obtiene el primer usuario (único)
        localStorage.setItem('user', JSON.stringify(user)); // Guarda datos del usuario localmente
        alert('Inicio de sesión exitoso');
        window.location.href = './dashboard.html'; // Redirige al panel principal
      } else {
        // Si la contraseña no coincide
        alert('Contraseña incorrecta');
      }
    } catch (err) {
      // Si ocurre algún error de red o conexión
      console.error(err);
      alert('Error al iniciar sesión');
    }
  });
}

/* ========== BLOQUE DE REGISTRO DE USUARIOS ========== */
if (registerForm) {
  // Escucha el evento de envío del formulario de registro
  registerForm.addEventListener('submit', async (e) => {
    e.preventDefault(); // Previene recarga de la página

    // Captura los datos ingresados
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    try {
      // Verifica si ya hay un usuario registrado con ese nombre
      const check = await fetch(`http://localhost:3002/users?username=${username}`);
      const existing = await check.json();

      // Si ya existe, no deja continuar
      if (existing.length > 0) {
        alert('Este usuario ya existe');
        return;
      }

      // Crea un nuevo objeto de usuario con rol "visitor"
      const newUser = {
        username,
        password,
        role: "visitor"  // Todos los nuevos usuarios tienen este rol
      };

      // Envia los datos del nuevo usuario al servidor
      const res = await fetch('http://localhost:3002/users', {
        method: 'POST', // Método POST para enviar datos
        headers: { 'Content-Type': 'application/json' }, // Especifica que los datos están en JSON
        body: JSON.stringify(newUser) // Convierte el objeto a JSON
      });

      // Si todo sale bien, avisa y redirige al login
      if (res.ok) {
        alert('Registrado con éxito');
        window.location.href = './login.html';
      } else {
        // Si falla el registro
        alert('Error al registrar usuario');
      }
    } catch (err) {
      // Captura errores de conexión
      console.error(err);
      alert('Error al conectar con el servidor');
    }
  });
}